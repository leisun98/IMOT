function storedb = setStore(problem, x, storedb, store) %#ok<INUSD>

    error('This file was removed from Manopt. Please use the StoreDB class.');

end
