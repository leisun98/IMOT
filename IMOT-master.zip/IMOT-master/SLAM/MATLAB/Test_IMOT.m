%% IMOT for SLAM (Pose Graph Optimization)
%
% Paper: Lei Sun, IMOT: General-Purpose, Fast and Robust Estimation for
% Spatial Perception Problems with Outliers, 2022
%
% Copyright by Lei Sun (leisunjames@126.com), for academic use only
% Adapted from the open-source implementation of [1]

clc; clear all; close all;
disp('---SLAM---');
run('import_SE_Sync.m');

%% Adjust parameters
data_dir = '../data/'; 

% name of dataset
intel = 'intel';

% choose the dataset to run for this problem
file = intel;
g2o_file = strcat(data_dir, file, '.g2o');

% set outlier ratio (0 to 0.8-0.9)
outlier_ratio=0.5;


%% Algorithm starts from here

noise=0.05; % set noise by default
inlier_thres=5*noise; % get inlier threshold
tic();
fprintf('Loading file: %s ...\n', g2o_file);
measurements = load_g2o_data(g2o_file);  
t = toc();
num_poses = max(max(measurements.edges));
num_measurements = length(measurements.kappa);
d = length(measurements.t{1});
fprintf('Processed input file %s in %g seconds\n', g2o_file, t);
fprintf('Number of poses: %d\n', num_poses);
fprintf('Number of measurements: %d\n', num_measurements);
% get ground-truth map
[~, ~,xhat_gt,~, ~, ~] = SE_Sync(measurements);
[f,t_hat_anchored_gt]=plot_poses(xhat_gt.t, xhat_gt.R, measurements.edges, '-b', .3);
title('Ground-Truth Trajectory','fontSize',12);

% create outliers 
R_temp=measurements.R;
t_temp=measurements.t;
edges_temp=measurements.edges;
kappa_temp=measurements.kappa;
tau_temp=measurements.tau;

n_ele=num_measurements-num_poses+1;
outlierIndex=num_poses-1+randperm(n_ele,round(outlier_ratio*n_ele));
for i= outlierIndex
    A=rand(1);
    a=rand(1);
    a(a>0.5)=1;
    a(a<=0.5)=-1;
    B=a*sqrt(1-A^2);
    R_temp{i}=[A,-B;B,A];
    t_temp{i}=0.5-1*rand(2,1);
end

measurements.R=R_temp;
measurements.t=t_temp;
measurements.edges=edges_temp;
measurements.kappa=kappa_temp;
measurements.tau=tau_temp;
num_poses = max(max(measurements.edges));
num_measurements = length(measurements.kappa);


%% SE-Sync (naive solver)
t1=tic;
[~, ~,xhat_se,~, ~, ~] = SE_Sync(measurements);
[t_hat_anchored_se]=plot_poses2(xhat_se.t, xhat_se.R, measurements.edges, '-r', .3);
trajectory_error_SESync=norm(mean(abs(t_hat_anchored_gt-t_hat_anchored_se),2));
time_SE_Sync=toc(t1);



%% IMOT

t1=tic;

% Preparation (separating odometry from loop closures)
Med=measurements.edges;
measurements_odo.edges=Med(1:num_poses-1,:);
Med=measurements.R;
measurements_odo.R=Med(1:num_poses-1);
Med=measurements.t;
measurements_odo.t=Med(1:num_poses-1);
Med=measurements.kappa;
measurements_odo.kappa=Med(1:num_poses-1);
Med=measurements.tau;
measurements_odo.tau=Med(1:num_poses-1);

Med=measurements.edges;
measurements_loop.edges=Med(num_poses:num_measurements,:);
Med=measurements.R;
measurements_loop.R=Med(num_poses:num_measurements);
Med=measurements.t;
measurements_loop.t=Med(num_poses:num_measurements);
Med=measurements.kappa;
measurements_loop.kappa=Med(num_poses:num_measurements);
Med=measurements.tau;
measurements_loop.tau=Med(num_poses:num_measurements);

re=zeros(1,num_measurements-num_poses+1);thres=zeros(1,50);thres2=zeros(1,50);best_set=[];
ostu_itr=4;max_itr_IMOT=50;

Edges=measurements_loop.edges;
Kappa=measurements_loop.kappa;
Tau=measurements_loop.tau;
R_gt=measurements_loop.R;
t_gt=measurements_loop.t;

for NM_itr=1:max_itr_IMOT
    
    Med=measurements_loop.edges;
    measurements_this.edges=[measurements_odo.edges;Med(best_set,:)];
    Med=measurements_loop.R;
    measurements_this.R=[measurements_odo.R,Med(best_set)];
    Med=measurements_loop.t;
    measurements_this.t=[measurements_odo.t,Med(best_set)]; 
    Med=measurements_loop.kappa;
    measurements_this.kappa=[measurements_odo.kappa,Med(best_set)];
    Med=measurements_loop.tau;
    measurements_this.tau=[measurements_odo.tau,Med(best_set)];

[~, ~,xhat_, ~, ~, ~] = SE_Sync(measurements_this);

% Compute residual errors
R_med=xhat_.R;t_med=xhat_.t;R_opt=cell(1);t_opt=cell(1);
for i=1:num_poses
    R_opt{i}=R_med(:,2*i-1:2*i);
    t_opt{i}=t_med(:,i);
end
for i=1:n_ele
    nr1=Edges(i,1);nr2=Edges(i,2);
    R_err=cell2mat(R_opt(nr1))*cell2mat(R_gt(i))-cell2mat(R_opt(nr2));
    t_err=cell2mat(t_opt(nr2))-cell2mat(t_opt(nr1))-cell2mat(R_opt(nr1))*cell2mat(t_gt(i));
    re(i)=sqrt(0.5*Kappa{i}/(Kappa{i}+Tau{i})*norm(R_err(:))^2+Tau{i}/(Kappa{i}+Tau{i})*norm(t_err)^2);  % Kappa{i}/(Kappa{i}+Tau{i})  Tau{i}/(Kappa{i}+Tau{i})
end

Upper=max(re);

unit_num=200;

unit=Upper/unit_num;

votes=zeros(1,unit_num+1);

for i=1:n_ele
    x=floor(re(i)/unit)+1;
    votes(x)=votes(x)+1;
end

coe=zeros(1,1);
for ree=1:ostu_itr

serial=1:numel(votes);
p = votes' / sum(votes);
omega = cumsum(p);
mu = cumsum(p .* (serial)');
mu_t = mu(end);

Gvariance=sum((serial'-mu_t).^2.*p);

sigma_b_squared = (mu_t * omega - mu).^2 ./ (omega .* (1 - omega));

bcvariance=sigma_b_squared/Gvariance;

[max_bc,vote_idx]=max(bcvariance);

votes=votes(1:vote_idx);

% figure,bar(unit*[1:numel(votes)],votes);title('Area Histogram','fontSize',15);

coe(ree)=max_bc;

end

thres(NM_itr)=unit*vote_idx;

thres2(NM_itr)=coe(ree);

if NM_itr>1 && abs(thres(NM_itr)-thres(NM_itr-1))<=1e-3
        break
end

best_set=zeros(1,1);co=0;
for i=1:n_ele
    if re(i)<=thres(NM_itr)
        co=co+1;
        best_set(co)=i;
    end
end

end

time_IMOT_=toc(t1);

opt_set=best_set;

if thres(NM_itr)>=5*inlier_thres
    refine_itr=2;
else
    refine_itr=0;
end
    
    xhat=xhat_;
    diff_thres=thres(NM_itr)-inlier_thres;
        
    for inn=1:refine_itr

        % Compute residual errors
        R_med=xhat.R;t_med=xhat.t;R_opt=cell(1);t_opt=cell(1);
        for i=1:num_poses
            R_opt{i}=R_med(:,2*i-1:2*i);
            t_opt{i}=t_med(:,i);
        end
        for i=1:n_ele
            nr1=Edges(i,1);nr2=Edges(i,2);
            R_err=cell2mat(R_opt(nr1))*cell2mat(R_gt(i))-cell2mat(R_opt(nr2));
            t_err=cell2mat(t_opt(nr2))-cell2mat(t_opt(nr1))-cell2mat(R_opt(nr1))*cell2mat(t_gt(i));
            re(i)=sqrt(0.5*Kappa{i}/(Kappa{i}+Tau{i})*norm(R_err(:))^2+Tau{i}/(Kappa{i}+Tau{i})*norm(t_err)^2);  
        end
        best_set=zeros(1,1);co=0;
        for i=1:n_ele
            if re(i)<=thres(NM_itr)-((inn-1)/refine_itr)*diff_thres
                co=co+1;
                best_set(co)=i;
            end
        end
        
        Med=measurements_loop.edges;
        measurements_this.edges=[measurements_odo.edges;Med(best_set,:)];
        Med=measurements_loop.R;
        measurements_this.R=[measurements_odo.R,Med(best_set)];
        Med=measurements_loop.t;
        measurements_this.t=[measurements_odo.t,Med(best_set)];
        Med=measurements_loop.kappa;
        measurements_this.kappa=[measurements_odo.kappa,Med(best_set)];
        Med=measurements_loop.tau;
        measurements_this.tau=[measurements_odo.tau,Med(best_set)];

        [~, ~, xhat,~, ~, ~] = SE_Sync(measurements_this);

    end
    
% Compute residual errors
R_med=xhat.R;t_med=xhat.t;R_opt=cell(1);t_opt=cell(1);
for i=1:num_poses
    R_opt{i}=R_med(:,2*i-1:2*i);
    t_opt{i}=t_med(:,i);
end
for i=1:n_ele
    nr1=Edges(i,1);nr2=Edges(i,2);
    R_err=cell2mat(R_opt(nr1))*cell2mat(R_gt(i))-cell2mat(R_opt(nr2));
    t_err=cell2mat(t_opt(nr2))-cell2mat(t_opt(nr1))-cell2mat(R_opt(nr1))*cell2mat(t_gt(i));
    re(i)=sqrt(0.5*Kappa{i}/(Kappa{i}+Tau{i})*norm(R_err(:))^2+Tau{i}/(Kappa{i}+Tau{i})*norm(t_err)^2);
end
best_set=zeros(1,1);co=0;
for i=1:n_ele
    if re(i)<=inlier_thres
        co=co+1;
        best_set(co)=i;
    end
end

Med=measurements_loop.edges;
measurements_this.edges=[measurements_odo.edges;Med(best_set,:)];
Med=measurements_loop.R;
measurements_this.R=[measurements_odo.R,Med(best_set)];
Med=measurements_loop.t;
measurements_this.t=[measurements_odo.t,Med(best_set)];
Med=measurements_loop.kappa;
measurements_this.kappa=[measurements_odo.kappa,Med(best_set)];
Med=measurements_loop.tau;
measurements_this.tau=[measurements_odo.tau,Med(best_set)];

% Use default settings for everything
[~, ~, xhat,~, ~, ~] = SE_Sync(measurements_this);

time_IMOT=toc(t1);

% Plot resulting SLAM pose graph
plot_loop_closures = true;

if plot_loop_closures
    [t_hat_anchored]=plot_poses2(xhat.t, xhat.R, measurements.edges, '-r', .3);
    [t_hat_anchored_]=plot_poses2(xhat_.t, xhat_.R, measurements.edges, '-r', .3);
else
    plot_poses2(xhat.t, xhat.R);
end
axis tight;

trajectory_error_IMOT=norm(mean(abs(t_hat_anchored_gt-t_hat_anchored),2));
trajectory_error_IMOT_=norm(mean(abs(t_hat_anchored_gt-t_hat_anchored_),2));
iteration_IMOT=NM_itr+refine_itr+1;
iteration_IMOT_=NM_itr;

disp('-Results of IMOT');
fprintf('Runtime [s]: %d \n',time_IMOT);
fprintf('Average Trajectory Error [deg]: %d \n',trajectory_error_IMOT);
fprintf('Number of Iterations: %d \n',iteration_IMOT);

disp('-Results of IMOT*');
fprintf('Runtime [s]: %d \n',time_IMOT_);
fprintf('Average Trajectory Error [deg]: %d \n',trajectory_error_IMOT_);
fprintf('Number of Iterations: %d \n',iteration_IMOT_);



%% References:

% [1] David M Rosen, Luca Carlone, Afonso S Bandeira, and John J Leonard. Se-sync: A certifiably correct algorithm for synchronization over the special euclidean group. The International Journal of Robotics Research, 38(2-3):95�125, 2019.
