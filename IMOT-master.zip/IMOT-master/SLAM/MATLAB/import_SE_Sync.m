cd SE-Sync/manopt
importmanopt;
cd ../lib
addpath(pwd);
cd ../..
