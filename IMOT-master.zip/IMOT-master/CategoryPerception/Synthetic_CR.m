function problem = Synthetic_CR(problem)

if ~isfield(problem,'N'); error('Please use problem.N to specify number of keypoints.'); end
if ~isfield(problem,'K'); problem.K = 2; end
if ~isfield(problem,'noiseSigma'); problem.noiseSigma = 0.01; end
if ~isfield(problem,'outlierRatio'); problem.outlierRatio = 0.0; end
if ~isfield(problem,'intraRadius'); problem.intraRadius = 0.2; end
if ~isfield(problem,'translationBound'); problem.translationBound = 10.0; end

N               = problem.N;
K               = problem.K;
noiseSigma      = problem.noiseSigma;
outlierRatio    = problem.outlierRatio;
intraRadius     = problem.intraRadius;
translationBound= problem.translationBound;

% generate a mean shape centered at zero
mean_shape = randn(3,N);
mean_shape = mean_shape - mean(mean_shape,2);

shapes     = zeros(3,N,K);
for k = 1:K
    shapes(:,:,k)  = mean_shape + intraRadius * randn(3,N);
end

% ground truth c, R, t
c_gt           = rand(K,1);
c_gt           = c_gt/sum(c_gt); % c sum up to one
R_gt           = rand_rotation;
t_gt           = randn(3,1); t_gt = t_gt/norm(t_gt);
t_gt           = translationBound * rand * t_gt;

% generate a noisy scene
shape          = combine_shapes(shapes,c_gt);
scene          = R_gt * shape + t_gt + noiseSigma * randn(3,N);

mean_scene=mean(scene,2);

% generate outliers
nrOutliers     = round(N*outlierRatio);
if nrOutliers > 0
    fprintf('Category registration: generate %d outliers.\n',nrOutliers);
    outlierIDs  = 1:nrOutliers;
    outliers    = mean_scene+1.5*randn(3,nrOutliers);
    scene(:,outlierIDs) = outliers;
else
    outlierIDs   = [];
end

theta_gt   = ones(N,1);
theta_gt(outlierIDs) = -1;

problem.type                = 'category registration';
problem.shape               = shape;
problem.shapes              = shapes;
problem.scene               = scene;
problem.nrOutliers          = nrOutliers;
problem.outlierIDs          = outlierIDs;
problem.c_gt                = c_gt;
problem.R_gt                = R_gt;
problem.t_gt                = t_gt;
problem.cBound              = 1.0;
problem.theta_gt            = theta_gt;
problem.noiseBound          = 6*noiseSigma;

fprintf('N: %d, num outliers: %d, noise bound: %g, translation bound: %g, c bound: %g\n',...
    problem.N,problem.nrOutliers,problem.noiseBound,problem.translationBound,problem.cBound);

end


function R=rand_rotation

%Generate random rotation
axis1= rand(1,3)-0.5;

axis1=axis1/norm(axis1);

angle=2*pi*rand(1);

aa = angle * axis1;

if norm(aa) < 2e-16
         R=eye(3);
else k = aa / norm(aa);
K1=[0, -k(3), k(2); k(3), 0, -k(1); -k(2), k(1), 0];

%construct a rotation matrix from an axis angle representation
R = eye(3) + sin(norm(aa)) * K1 + (1 -cos(norm(aa))) * K1 * K1;
end

end