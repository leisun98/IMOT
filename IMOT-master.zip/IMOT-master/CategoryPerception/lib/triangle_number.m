function ndelta = triangle_number(n)
ndelta  = (n.*(n+1))/2;
end