function x = mykron(a,b)
% x   = a * b';
x   = b * a';
x   = x(:);
end