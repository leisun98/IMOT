function str = logical2str(logic)

if logic
    str = 'True';
else
    str = 'False';
end