function R_opt = NonMinimal_RS(pts_3d,pts_3d_,best_set)

best_size=length(best_set);

if best_size<=1
    R_opt=eye(3);
    return
end

H=zeros(3,3);

for i=1:best_size
    H=H+(pts_3d(best_set(i),:)')*(pts_3d_(best_set(i),:)')';
end

[U,~,V]=svd(H);

R_opt=V*U';

end

