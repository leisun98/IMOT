%% IMOT for Single Rotation Averaging
%
% Paper: Lei Sun, IMOT: General-Purpose, Fast and Robust Estimation for
% Spatial Perception Problems with Outliers, 2022
%
% Copyright by Lei Sun (leisunjames@126.com), for academic use only
% Adapted from the open-source implementation of [1]

clc; clear all; close all;
disp('---Single Rotation Averaging---');

%% Adjust parameters 

% set measurement number 
n_ele=100;  % default: 100

% set noise in degrees
noise = 5;  % default: 5 degrees

% set outlier ratio (0 to 0.7)
outlier_ratio=0.5;

%% Algorithm starts from here

inlier_thres=3*noise; % get inlier threshold
n_inliers = n_ele*(1-outlier_ratio);
n_outliers = n_ele*(outlier_ratio);
R_gt = RandomRotation(pi);

% initiate problem
n_samples = n_inliers + n_outliers;
R_samples = cell(1, n_samples);
% create input rotaions
for i = 1:n_samples
    if (i > n_outliers)
        % Inliers: corrupted by noise
        axis_perturb = rand(3,1)-0.5;
        axis_perturb = axis_perturb/norm(axis_perturb);
        angle_perturb = normrnd(0,noise/180*pi); 
        R_perturb = RotationFromUnitAxisAngle(axis_perturb, angle_perturb);
        R_samples{i} = R_perturb*R_gt;
    else
        % Outliers: completely random
        axis1= rand(1,3)-0.5;
        axis1=axis1/norm(axis1);
        angle=2*pi*rand(1);
        aa = angle * axis1;
        k = aa / norm(aa);
        K1=[0, -k(3), k(2); k(3), 0, -k(1); -k(2), k(1), 0];
        R2 = eye(3) + sin(norm(aa)) * K1 + (1 -cos(norm(aa))) * K1 * K1;
        R_samples{i}=R2;
        ok=0;
    end
end
R_Samples=R_samples;


%% IMOT

tic;

n_ele=n_inliers+n_outliers;re=zeros(1,n_ele);thres=zeros(1,50);thres2=zeros(1,50);best_set=1:n_ele;
ostu_itr=2;max_itr_IMOT=50;R_input=R_Samples;

for NM_itr=1:max_itr_IMOT

R_samples=R_input(best_set);
n_samples = length(R_samples);

vectors_total = zeros(9,n_samples);
for i = 1:n_samples
    vectors_total(:,i)= R_samples{i}(:);
end
s = median(vectors_total,2);
    
[U,~,V] = svd(reshape(s, [3 3]));
R = U*V.';
if (det(R) < 0)
    V(:,3) = -V(:,3);
    R = U*V.';
end

for i=1:n_ele
    re(i)=AngularError(R,R_input{i})*180/pi;
end

Upper=max(re);

unit_num=200;

unit=Upper/unit_num;

votes=zeros(1,unit_num+1);

for i=1:n_ele
    x=floor(re(i)/unit)+1;
    votes(x)=votes(x)+1;
end

coe=zeros(1,1);
for ree=1:ostu_itr

serial=1:numel(votes);
p = votes' / sum(votes);
omega = cumsum(p);
mu = cumsum(p .* (serial)');
mu_t = mu(end);

Gvariance=sum((serial'-mu_t).^2.*p);

sigma_b_squared = (mu_t * omega - mu).^2 ./ (omega .* (1 - omega));

bcvariance=sigma_b_squared/Gvariance;

[max_bc,vote_idx]=max(bcvariance);

votes=votes(1:vote_idx);

% figure,bar(unit*[1:numel(votes)],votes);title('Area Histogram','fontSize',15);

coe(ree)=max_bc;

end

thres(NM_itr)=unit*vote_idx-unit;

thres2(NM_itr)=coe(ree);

if NM_itr>1 && abs(thres(NM_itr)-thres(NM_itr-1))<=5e-3
        break
end

best_set=zeros(1,1);co=0;
for i=1:n_ele
    if re(i)<=thres(NM_itr)
        co=co+1;
        best_set(co)=i;
    end
end

end


if thres(NM_itr)>=5*inlier_thres
    refine_itr=2;
else
    refine_itr=0;
end

diff_thres=thres(NM_itr)-inlier_thres;
R_opt=R;
        
for inn=1:refine_itr

for i=1:n_ele
     re(i)=AngularError(R_opt,R_input{i})*180/pi;
end

best_set=zeros(1,1);co=0;
for i=1:n_ele
    if re(i)<=thres(NM_itr)-((inn-1)/refine_itr)*diff_thres
        co=co+1;
        best_set(co)=i;
    end
end
        
R_samples=R_input(best_set);

n_samples = length(R_samples);
    
vectors_total = zeros(9,n_samples);
for i = 1:n_samples
    vectors_total(:,i)= R_samples{i}(:);
end
s = median(vectors_total,2);
    
[U,~,V] = svd(reshape(s, [3 3]));
R_opt = U*V.';
if (det(R_opt) < 0)
    V(:,3) = -V(:,3);
    R_opt = U*V.';
end

end

for i=1:n_ele
     re(i)=AngularError(R_opt,R_input{i})*180/pi;
end

best_set=ones(1,1);co=0;
for i=1:n_ele
     if re(i)<=inlier_thres
          co=co+1;
          best_set(co)=i;
     end
end

R_samples=R_input(best_set);

n_samples = length(R_samples);
    
vectors_total = zeros(9,n_samples);
for i = 1:n_samples
    vectors_total(:,i)= R_samples{i}(:);
end
s = median(vectors_total,2);
    
[U,~,V] = svd(reshape(s, [3 3]));
R_opt = U*V.';
if (det(R_opt) < 0)
    V(:,3) = -V(:,3);
    R_opt = U*V.';
end

time_IMOT=toc();
R_error_IMOT=AngularError(R_opt,R_gt)*180/pi;
iteration_IMOT=NM_itr+refine_itr+1;

disp('-Results of IMOT');
fprintf('Runtime [s]: %d \n',time_IMOT);
fprintf('Rotation Error [deg]: %d \n',R_error_IMOT);
fprintf('Number of Iterations: %d \n',iteration_IMOT);



%% IMOT*

tic;

n_ele=n_inliers+n_outliers;re=zeros(1,n_ele);thres=zeros(1,50);thres2=zeros(1,50);best_set=1:n_ele;
ostu_itr=2;max_itr_IMOT=50;R_input=R_Samples;

for NM_itr=1:max_itr_IMOT

R_samples=R_input(best_set);
n_samples = length(R_samples);

vectors_total = zeros(9,n_samples);
for i = 1:n_samples
    vectors_total(:,i)= R_samples{i}(:);
end
s = median(vectors_total,2);
    
[U,~,V] = svd(reshape(s, [3 3]));
R = U*V.';
if (det(R) < 0)
    V(:,3) = -V(:,3);
    R = U*V.';
end

for i=1:n_ele
    re(i)=AngularError(R,R_input{i})*180/pi;
end

Upper=max(re);

unit_num=200;

unit=Upper/unit_num;

votes=zeros(1,unit_num+1);

for i=1:n_ele
    x=floor(re(i)/unit)+1;
    votes(x)=votes(x)+1;
end

coe=zeros(1,1);
for ree=1:ostu_itr

serial=1:numel(votes);
p = votes' / sum(votes);
omega = cumsum(p);
mu = cumsum(p .* (serial)');
mu_t = mu(end);

Gvariance=sum((serial'-mu_t).^2.*p);

sigma_b_squared = (mu_t * omega - mu).^2 ./ (omega .* (1 - omega));

bcvariance=sigma_b_squared/Gvariance;

[max_bc,vote_idx]=max(bcvariance);

votes=votes(1:vote_idx);

% figure,bar(unit*[1:numel(votes)],votes);title('Area Histogram','fontSize',15);

coe(ree)=max_bc;

end

thres(NM_itr)=unit*vote_idx-unit;

thres2(NM_itr)=coe(ree);

if NM_itr>1 && abs(thres(NM_itr)-thres(NM_itr-1))<=5e-3
        break
end

best_set=zeros(1,1);co=0;
for i=1:n_ele
    if re(i)<=thres(NM_itr)
        co=co+1;
        best_set(co)=i;
    end
end

end

time_IMOT_star=toc();
R_error_IMOT_star=AngularError(R,R_gt)*180/pi;
iteration_IMOT_star=NM_itr;

disp('-Results of IMOT*');
fprintf('Runtime [s]: %d \n',time_IMOT_star);
fprintf('Rotation Error [deg]: %d \n',R_error_IMOT_star);
fprintf('Number of Iterations: %d \n',iteration_IMOT_star);



%% Functions

function out = logarithm_map(in)
    cos_theta = (trace(in)-1)/2;
    sin_theta = sqrt(1-cos_theta^2);
    theta = acos(cos_theta);
    ln_R = theta/(2*sin_theta)*(in-in');
    out = [ln_R(3,2);ln_R(1,3);ln_R(2,1)];
end


function out = SkewSymmetricMatrix(in)
    out=[0 -in(3) in(2) ; in(3) 0 -in(1) ; -in(2) in(1) 0 ];
end

function R = RandomRotation(max_angle_rad)

    unit_axis = rand(3,1)-0.5;
    unit_axis = unit_axis/norm(unit_axis);
    angle = rand*max_angle_rad;
    R = RotationFromUnitAxisAngle(unit_axis, angle);

end

function R = RotationFromUnitAxisAngle(unit_axis, angle)
    
    if (angle==0)
        R = eye(3);
    else
        so3 = SkewSymmetricMatrix(unit_axis);
        R = eye(3)+so3*sin(angle)+so3^2*(1-cos(angle));
    end
end

function R = ProjectOntoSO3(M)   
    [U,~,V] = svd(M);
    R = U*V.';
    if (det(R) < 0)
        V(:,3) = -V(:,3);
        R = U*V.';
    end
end


function R = GeodesicL1Mean(R_input, b_outlier_rejection, n_iterations, thr_convergence)
    
    % 1. Initialize
    
    n_samples = length(R_input);
    
    vectors_total = zeros(9,n_samples);
    for i = 1:n_samples
        vectors_total(:,i)= R_input{i}(:);
    end
    s = median(vectors_total,2);
    
    [U,~,V] = svd(reshape(s, [3 3]));
    R = U*V.';
    if (det(R) < 0)
        V(:,3) = -V(:,3);
        R = U*V.';
    end
    
    % 2. Optimize
    
    for j = 1:n_iterations

        vs = zeros(3,n_samples);
        v_norms = zeros(1,n_samples);
        for i = 1:n_samples
            v =  logarithm_map(R_input{i}*R');
            v_norm = norm(v);
            vs(:,i) = v;
            v_norms(i) = v_norm;
        end
        
        % Compute the inlier threshold (if we reject outliers).
        thr = inf;
        if (b_outlier_rejection)
            sorted_v_norms = sort(v_norms);
            v_norm_firstQ = sorted_v_norms(ceil(n_samples/4));
            if (n_samples <= 50)
                thr = max(v_norm_firstQ, 1);

            else
                thr = max(v_norm_firstQ, 0.5);
            end
        end

        step_num = 0;
        step_den = 0;

        for i = 1:n_samples
            v =  vs(:,i);
            v_norm = v_norms(i);
            if (v_norm > thr)
                continue;
            end
            step_num = step_num + v/v_norm;
            step_den = step_den + 1/v_norm;
        end

        delta = step_num/step_den;
        delta_angle = norm(delta);
        delta_axis = delta/delta_angle;
        
        R_delta = RotationFromUnitAxisAngle(delta_axis, delta_angle);
        R = R_delta*R;
        if (delta_angle < thr_convergence)
            break;
        end
    end
end


function R = ChordalL1Mean(R_input, b_outlier_rejection, n_iterations, thr_convergence)
    
    % 1. Initialize
    n_samples = length(R_input);
    
    vectors_total = zeros(9,n_samples);
    for i = 1:n_samples
        vectors_total(:,i)= R_input{i}(:);
    end      

    s = median(vectors_total,2);
                
    % 2. Optimize
    for j = 1:n_iterations
        if (sum(sum(abs(vectors_total-s))==0) ~= 0)
            s = s+rand(size(s,1),1)*0.001;
        end

        v_norms = zeros(1,n_samples);
        for i = 1:n_samples
            v =  vectors_total(:,i)-s;
            v_norm = norm(v);
            v_norms(i) = v_norm;
        end

        % Compute the inlier threshold (if we reject outliers).
        thr = inf;
        if (b_outlier_rejection)
            sorted_v_norms = sort(v_norms);
            v_norm_firstQ = sorted_v_norms(ceil(n_samples/4));

            if (n_samples <= 50)
                thr = max(v_norm_firstQ, 1.356);
                % 2*sqrt(2)*sin(1/2) is approximately 1.356
            else
                thr = max(v_norm_firstQ, 0.7);
                % 2*sqrt(2)*sin(0.5/2) is approximately 0.7
            end
        end

        step_num = 0;
        step_den = 0;

        for i = 1:n_samples
            v_norm = v_norms(i);
            if (v_norm > thr)
                continue;
            end
            step_num = step_num + vectors_total(:,i)/v_norm;
            step_den = step_den + 1/v_norm;
        end


        s_prev = s;
        s = step_num/step_den;

        update_medvec = s-s_prev;
        if (norm(update_medvec) < thr_convergence)
            break;
        end

    end
    
    R = ProjectOntoSO3(reshape(s, [3 3]));

end



function cross_ten_x = cross_ten( x )
% Skew symetric matrix permiting to express the cross product: x * .
    X = x(1);
    Y = x(2);
    Z = x(3);
    cross_ten_x = [  0 , -Z ,  Y ;...
                     Z ,  0 , -X ;...
                    -Y ,  X ,  0 ];
end

function v = lie_log( R )
% Lie-Logarithm
% Function such that: 
%     expm(cross_ten(       lie_log(R)       )) = R
    [V,D] = eig(R);
    [theta,i] = max(angle(diag(D)));
    [   ~ ,k] = min(abs(diag(D)-1));
    v1 = theta*V(:,k);
    v2 =-theta*V(:,k);
    R1 = expm(cross_ten( v1 ));
    R2 = expm(cross_ten( v2 ));
    if max(angle(eig(R * R2'))) > max(angle(eig(R * R1')))
        v = v1;
    else
        v = v2;
    end
end


%% References:

% [1] Seong Hun Lee and Javier Civera. Robust single rotation averaging .arXiv preprint arXiv:2004.00732, 2020.
