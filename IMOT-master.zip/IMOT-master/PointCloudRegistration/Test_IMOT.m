%% IMOT for Point Cloud Registration
%
% Paper: Lei Sun, IMOT: General-Purpose, Fast and Robust Estimation for
% Spatial Perception Problems with Outliers, 2022
%
% Copyright by Lei Sun (leisunjames@126.com), for academic use only

clc; clear all; close all;
disp('---Point Cloud Registration---');

%% Adjust parameters

% set measurement number
n_ele=1000; % default: 1000

% set noise 
noise=0.01; % default: 0.01

% set outlier ratio (0 to 0.9)
outlier_ratio=0.5;

%% Algorithms starts from here

inlier_thres=5*noise; % get inlier threshold

% generate problem
[pts_3d,pts_3d_,R_gt,t_gt]=Semi_Synthetic_PCR(n_ele,noise,outlier_ratio,1,0);



%% IMOT

tic;

re=zeros(1,n_ele);thres=zeros(1,50);thres2=zeros(1,50);best_set=1:n_ele;
ostu_itr=3;max_itr_IMOT=50;

for NM_itr=1:max_itr_IMOT

[R_opt,t_opt] = NonMinimalSol_PCR(pts_3d,pts_3d_,best_set);

for i=1:n_ele
    re(i)=norm(R_opt*pts_3d(i,:)'+t_opt-pts_3d_(i,:)');
end

Upper=max(re);

unit_num=200;

unit=Upper/unit_num;

votes=zeros(1,unit_num+1);

for i=1:n_ele
    x=floor(re(i)/unit)+1;
    votes(x)=votes(x)+1;
end

coe=zeros(1,1);
for ree=1:ostu_itr

serial=1:numel(votes);
p = votes' / sum(votes);
omega = cumsum(p);
mu = cumsum(p .* (serial)');
mu_t = mu(end);

Gvariance=sum((serial'-mu_t).^2.*p);

sigma_b_squared = (mu_t * omega - mu).^2 ./ (omega .* (1 - omega));

bcvariance=sigma_b_squared/Gvariance;

[max_bc,vote_idx]=max(bcvariance);

votes=votes(1:vote_idx);

% figure,bar(unit*[1:numel(votes)],votes);title('Area Histogram','fontSize',15);

coe(ree)=max_bc;

end

thres(NM_itr)=unit*vote_idx;

thres2(NM_itr)=coe(ree);

if NM_itr>1 && abs(thres(NM_itr)-thres(NM_itr-1))<=5e-3
        break
end

best_set=zeros(1,1);co=0;
for i=1:n_ele
    if re(i)<=thres(NM_itr)
        co=co+1;
        best_set(co)=i;
    end
end

end

opt_set=best_set;

if thres(NM_itr)>=5*inlier_thres
    refine_itr=2;
else
    refine_itr=0;
end
    
    diff_thres=thres(NM_itr)-inlier_thres;
        
    for inn=1:refine_itr
        for i=1:n_ele
            re(i)=norm(R_opt*pts_3d(i,:)'+t_opt-pts_3d_(i,:)');
        end
        best_set=zeros(1,1);co=0;
        for i=1:n_ele
            if re(i)<=thres(NM_itr)-((inn-1)/refine_itr)*diff_thres
                co=co+1;
                best_set(co)=i;
            end
        end
        [R_opt,t_opt] = NonMinimalSol_PCR(pts_3d,pts_3d_,best_set);
    end

        for i=1:n_ele
            re(i)=norm(R_opt*pts_3d(i,:)'+t_opt-pts_3d_(i,:)');
        end
        best_set=zeros(1,1);co=0;
        for i=1:n_ele
            if re(i)<=inlier_thres
                co=co+1;
                best_set(co)=i;
            end
        end

[R_opt,t_opt] = NonMinimalSol_PCR(pts_3d,pts_3d_,best_set);


time_IMOT=toc();
R_error_IMOT=AngularError(R_opt,R_gt)*180/pi;
t_error_IMOT=norm(t_opt-t_gt');
iteration_IMOT=NM_itr+refine_itr+1;


disp('-Results of IMOT');
fprintf('Runtime [s]: %d \n',time_IMOT);
fprintf('Rotation Error [deg]: %d \n',R_error_IMOT);
fprintf('Translation Error [m]: %d \n',t_error_IMOT);
fprintf('Number of Iterations: %d \n',iteration_IMOT);



%% IMOT*

tic;

re=zeros(1,n_ele);thres=zeros(1,50);thres2=zeros(1,50);best_set=1:n_ele;
ostu_itr=3;max_itr_IMOT=50;

for NM_itr=1:max_itr_IMOT

[R_opt,t_opt] = NonMinimalSol_PCR(pts_3d,pts_3d_,best_set);

for i=1:n_ele
    re(i)=norm(R_opt*pts_3d(i,:)'+t_opt-pts_3d_(i,:)');
end

Upper=max(re);

unit_num=200;

unit=Upper/unit_num;

votes=zeros(1,unit_num+1);

for i=1:n_ele
    x=floor(re(i)/unit)+1;
    votes(x)=votes(x)+1;
end

coe=zeros(1,1);
for ree=1:ostu_itr

serial=1:numel(votes);
p = votes' / sum(votes);
omega = cumsum(p);
mu = cumsum(p .* (serial)');
mu_t = mu(end);

Gvariance=sum((serial'-mu_t).^2.*p);

sigma_b_squared = (mu_t * omega - mu).^2 ./ (omega .* (1 - omega));

bcvariance=sigma_b_squared/Gvariance;

[max_bc,vote_idx]=max(bcvariance);

votes=votes(1:vote_idx);

% figure,bar(unit*[1:numel(votes)],votes);title('Area Histogram','fontSize',15);

coe(ree)=max_bc;

end

thres(NM_itr)=unit*vote_idx;

thres2(NM_itr)=coe(ree);

if NM_itr>1 && abs(thres(NM_itr)-thres(NM_itr-1))<=5e-3
        break
end

best_set=zeros(1,1);co=0;
for i=1:n_ele
    if re(i)<=thres(NM_itr)
        co=co+1;
        best_set(co)=i;
    end
end

end

time_IMOT_star=toc();
R_error_IMOT_star=AngularError(R_opt,R_gt)*180/pi;
t_error_IMOT_star=norm(t_opt-t_gt');
iteration_IMOT_star=NM_itr;

disp('-Results of IMOT*');
fprintf('Runtime [s]: %d \n',time_IMOT_star);
fprintf('Rotation Error [deg]: %d \n',R_error_IMOT_star);
fprintf('Translation Error [deg]: %d \n',t_error_IMOT_star);
fprintf('Number of Iterations: %d \n',iteration_IMOT_star);

